    document.querySelectorAll("span.pipeline-new-node").forEach(function(div){
    	div.style.display = "none";
    	console.log("removed")
    })